﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","pl",{title:"Wybór koloru interfejsu",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Predefiniowane zestawy kolorów",config:"Wklej poniższy łańcuch znaków do pliku config.js:"});