﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","hr",{abort:"Slanje prekinuto od strane korisnika",doneOne:"Datoteka uspješno poslana.",doneMany:"Uspješno poslano %1 datoteka.",uploadOne:"Slanje datoteke ({percentage}%)...",uploadMany:"Slanje datoteka, {current} od {max} gotovo ({percentage}%)..."});